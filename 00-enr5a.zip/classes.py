# -*- coding: utf-8 -*-
"""
Created on Mon May 14 12:13:20 2018

@author: Enrico Aloisi Nardi
"""
#Abaixo definimos uma classe chamada Clientes
#Cada objeto dessa classe será um cliente nosso
#Dois métodos são aplicáveis aos objetos dessas classe (cliente):
#Podemos comprar ou vender
class Cliente: 
    carteira = {}
    saldo = 1E5
    def __init__(self):
        self.carteira={} 
        self.saldo=1E5
        #Essa classe possui dois atributos: carteira, um dicionário; e saldo, um float.
        #carteira é o dicionário estruturado em {acao:quantidade}, ex: {'Tesla':400}
        #Ou seja, temos 400 ações da Tesla
        #saldo é o dinheiro disponível no banco para compra de ações, nesse caso 10k 
        
    def compra (self, acao, preco, quantidade): #O metodo compra recebe de acao, quantidade e preco
        self.saldo -= quantidade*preco #Uma quantidade do nosso dinheiro é removida
        if acao in self.carteira: #testamos se a acao já existe no dicionario
            self.carteira[acao] += quantidade # se ela existir só adicionamos a quantidade à ação
        else: #se ela n existir colocamos ela lá e lhe atribuimos o valor quantidade
            self.carteira[acao] = quantidade
    
    def venda(self, acao, preco, quantidade):
        self.saldo += quantidade*preco
        if acao in self.carteira: 
            self.carteira[acao] -= quantidade
        else: 
            self.carteira[acao] = quantidade
            
class Graficos:
    def __init__(self):
        self.tempo=[]
        self.valores_acoes=[]