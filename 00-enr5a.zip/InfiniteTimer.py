# -*- coding: utf-8 -*-
"""
Created on Friday June 01 12:13:20 2018

@author: Tony Montana from StackOverflow
"""
from threading import Timer

class InfiniteTimer(object):
    """Uma classe timer que nao para, a menos que voce queira."""

    def __init__(self, miliseconds, target):
        self._should_continue = False
        self.is_running = False
        self.seconds = miliseconds / 1000
        self.target = target
        self.thread = None
        
    def __del__(self):
        self.cancel()
        self.thread = None
        
    def destroy(self):
        self.__del__()
        
    def _handle_target(self):
        self.is_running = True
        self.target()
        self.is_running = False
        self._start_timer()

    def _start_timer(self):
        if self._should_continue: # Precisa estar rodando para cancelar.
            self.thread = Timer(self.seconds, self._handle_target)
            self.thread.start()

    def start(self):
        if not self._should_continue and not self.is_running:
            self._should_continue = True
            self._start_timer()

    def cancel(self):
        if self.thread is not None:
            self._should_continue = False # Somente no caso do Timer ja esta rodando e o cancel falhar.
            self.thread.cancel()
